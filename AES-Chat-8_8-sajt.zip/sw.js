/* AES-Chat service worker.
   Gör appen installerbar och startbar offline (själva skalet), och visar notiser på mobil.
   Rör ALDRIG anrop till andra domäner (Supabase, CDN, YouTube) — bara filer från den här sajten. */
// Versionen kommer från index.html (AES_VERSION) via adressen sw.js?v=… — ändra den INTE här.
const BUILD = new URL(self.location.href).searchParams.get("v") || "dev";
const CACHE = "aes-chat-" + BUILD;
const SHELL = ["./", "index.html", "manifest.webmanifest", "icon-192.png", "icon-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k.startsWith("aes-chat-") && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;                       // aldrig Supabase/CDN/YouTube
  if (url.pathname.endsWith("/version.json") || url.pathname.endsWith("/sw.js")) return; // alltid från nätet

  if (req.mode === "navigate") {
    // Nätet först (så man alltid får senaste versionen), cachen som reserv när man är offline
    e.respondWith(
      fetch(req)
        .then((res) => {
          if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put("index.html", copy)); }
          return res;
        })
        .catch(() => caches.match("index.html").then((r) => r || caches.match("./")))
    );
    return;
  }
  // Ikoner/manifest: cachen först
  e.respondWith(
    caches.match(req).then((hit) => hit || fetch(req).then((res) => {
      if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
      return res;
    }))
  );
});

self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  e.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((list) => {
      for (const c of list) { if ("focus" in c) return c.focus(); }
      return self.clients.openWindow("./");
    })
  );
});
